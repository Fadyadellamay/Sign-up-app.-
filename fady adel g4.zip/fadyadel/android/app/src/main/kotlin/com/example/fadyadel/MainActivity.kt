package com.example.fadyadel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
